# Changelog

## [v2.1.5]
### Updated
- Update dependencies
- Add link to generator in sidebar

## [v2.1.4]
### Updated
- Update dependencies

## [v2.1.3]
### Updated
- Add the screenshot to assets, change progress bar bg color, update main colors
- Badges: fix padding, font size
- Visits: fix checkbox in table, fix adaptive problem, fix progress bar percents position
- Charts: fix label colors, apex dropdown text
- Typography: fix justify content
- Notifications: fix colors
- Update readme and changelog
- Update dependencies

## [v2.1.2]

### Updated

- Update dependencies

## [v2.1.1]

### Updated

- Update dependencies
- Fix Echart Donut Chart

## [v2.1.0]

### Updated

- New Design

## [v2.0.0]

### Updated

- Remove All Jquery
